# Drop stale ART artifacts for the two replaced jars. ART regenerates them on
# the next boot; without this the old oat/vdex can shadow the new dex.
rm -rf /data/dalvik-cache/*/system@framework@* 2>/dev/null || true
rm -rf /data/dalvik-cache/*/system@services@* 2>/dev/null || true
ui_print "- cleared framework/services dalvik-cache entries"
ui_print "- first boot will take longer while ART recompiles"
